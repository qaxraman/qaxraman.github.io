﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlTest
{
    class Student
    {
        public int Id { get; set; }
        public string marka { get; set; }
        public string model { get; set; }
        public int Age { get; set; }

        public static IEnumerable<Student> GetAllStudents()
        {
            return new List<Student>
                {
                    new Student{Id = 100, marka = "Mercedes", model = "E class", Age = 22},
                    new Student{Id = 101, marka = "BMW", model = "745 i ", Age = 24},
                    new Student{Id = 102, marka = "Lexus", model = "G470", Age = 23},
                    new Student{Id = 103, marka = "lada", model = "2107", Age = 21},
                    new Student{Id = 104, marka = "lada", model = "niva", Age = 22}
            };
        }
    }
}
