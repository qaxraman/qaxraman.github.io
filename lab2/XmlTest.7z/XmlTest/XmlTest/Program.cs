﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
namespace XmlTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var xmlDoc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"),
                                       new XElement("cars",
                                                    Student.GetAllStudents().Select(
                                                        item => new XElement("Student", new XAttribute("Id", item.Id),
                                                                             new XElement("marka", item.marka),
                                                                             new XElement("model", item.model),
                                                                             new XElement("Age", item.Age)))));
            xmlDoc.Save(System.IO.Path.Combine(Environment.CurrentDirectory, "xmlDoc.xml"));
            Console.ReadKey();
        }
    }
}
